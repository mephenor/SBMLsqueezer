/*
 * $Id: Event.java 163 2010-02-24 14:25:51Z andreas-draeger $
 * $URL: https://jsbml.svn.sourceforge.net/svnroot/jsbml/branches/ZBIT/src/org/sbml/jsbml/Event.java $
 *
 * 
 *==================================================================================
 * Copyright (c) 2009 The jsbml team.
 *
 * This file is part of jsbml, the pure java SBML library. Please visit
 * http://sbml.org for more information about SBML, and http://jsbml.sourceforge.net/
 * to get the latest version of jsbml.
 *
 * jsbml is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 2.1 of the License, or
 * (at your option) any later version.
 *
 * jsbml is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with jsbml.  If not, see <http://www.gnu.org/licenses/old-licenses/lgpl-2.1.html>.
 *
 *===================================================================================
 *
 */

package org.sbml.jsbml;

/**
 * @author Andreas Dr&auml;ger <a
 *         href="mailto:andreas.draeger@uni-tuebingen.de">
 *         andreas.draeger@uni-tuebingen.de</a>
 * 
 */
public class Event extends AbstractNamedSBase {
	/**
	 * 
	 */
	private boolean useValuesFromTriggerTime;
	/**
	 * 
	 */
	private Trigger trigger;
	/**
	 * 
	 */
	private ListOf<EventAssignment> listOfEventAssignments;
	/**
	 * 
	 */
	private Delay delay;
	/**
	 * 
	 */
	private UnitDefinition timeUnits;
	
	/**
	 * 
	 * @param event
	 */
	public Event(Event event) {
		super(event);
		if (event.isSetTrigger())
			setTrigger(event.getTrigger().clone());
		else
			trigger = null;
		this.useValuesFromTriggerTime = event.isUseValuesFromTriggerTime();
		if (event.isSetDelay()) {
			setDelay(event.getDelay().clone());
		} else
			this.delay = null;
		setListOfEventAssignments(event.getListOfEventAssignments().clone());
		this.timeUnits = event.isSetTimeUnits() ? event.getTimeUnitsInstance()
				.clone() : null;
	}

	/**
	 * 
	 * @param level
	 * @param version
	 */
	public Event(int level, int version) {
		super(level, version);
		initDefaults();
	}

	/**
	 * 
	 * @param id
	 */
	public Event(String id, int level, int version) {
		super(id, level, version);
		initDefaults();
	}

	/**
	 * 
	 * @param id
	 * @param name
	 */
	public Event(String id, String name, int level, int version) {
		super(id, name, level, version);
		initDefaults();
	}

	/**
	 * 
	 * @param eventass
	 */
	public void addEventAssignment(EventAssignment eventass) {
		listOfEventAssignments.add(eventass);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.sbml.SBase#clone()
	 */
	// @Override
	public Event clone() {
		return new Event(this);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see org.sbml.SBase#equals(java.lang.Object)
	 */
	// @Override
	public boolean equals(Object o) {
		boolean equal = super.equals(o);
		if (equal && (o instanceof Event)) {
			Event e = (Event) o;
			equal &= e.getUseValuesFromTriggerTime() == getUseValuesFromTriggerTime();
			equal &= e.getListOfEventAssignments().equals(
					getListOfEventAssignments());
			if ((e.isSetDelay() && !isSetDelay())
					|| (!e.isSetDelay() && isSetDelay()))
				return false;
			else if (e.isSetDelay() && isSetDelay())
				equal &= e.getDelay().equals(getDelay());
			if ((!e.isSetTrigger() && isSetTrigger())
					|| (e.isSetTrigger() && !isSetTrigger()))
				return false;
			else if (e.isSetTrigger() && isSetTrigger())
				equal &= e.getTrigger().equals(getTrigger());
			if ((!e.isSetTimeUnits() && isSetTimeUnits())
					|| (e.isSetTimeUnits() && !isSetTimeUnits()))
				return false;
			else if (e.isSetTimeUnits() && isSetTimeUnits())
				equal &= e.getTimeUnits().equals(getTimeUnits());
		} else equal = false;
		return equal;
	}

	/**
	 * 
	 * @return
	 */
	public Delay getDelay() {
		return delay;
	}

	/**
	 * 
	 * @param n
	 * @return
	 */
	public EventAssignment getEventAssignment(int n) {
		return listOfEventAssignments.get(n);
	}

	/**
	 * 
	 * @return
	 */
	public ListOf<EventAssignment> getListOfEventAssignments() {
		return listOfEventAssignments;
	}

	/**
	 * 
	 * @return
	 */
	public int getNumEventAssignments() {
		return listOfEventAssignments.size();
	}

	/**
	 * 
	 * @return
	 */
	public String getTimeUnits() {
		return isSetTimeUnits() ? timeUnits.getId() : "";
	}

	/**
	 * 
	 * @return
	 */
	public UnitDefinition getTimeUnitsInstance() {
		return timeUnits;
	}
	
	/**
	 * 
	 * @return
	 */
	public Trigger getTrigger() {
		return trigger;
	}
	
	/**
	 * 
	 * @return
	 */
	public boolean getUseValuesFromTriggerTime() {
		return useValuesFromTriggerTime;
	}

	/**
	 * 
	 */
	public void initDefaults() {
		useValuesFromTriggerTime = true;
		setTrigger(new Trigger(getLevel(), getVersion()));
		setListOfEventAssignments(new ListOf<EventAssignment>(getLevel(), getVersion()));
		timeUnits = null;
		delay = null;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isSetDelay() {
		return delay != null;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isSetTimeUnits() {
		return timeUnits != null;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isSetTrigger() {
		return trigger != null;
	}

	/**
	 * 
	 * @return
	 */
	public boolean isUseValuesFromTriggerTime() {
		return useValuesFromTriggerTime;
	}

	/**
	 * 
	 * @param delay
	 */
	public void setDelay(Delay delay) {
		this.delay = delay;
		this.delay.parentSBMLObject = this;
		this.delay.sbaseAdded();
	}

	/**
	 * 
	 * @param listOfEventAssignments
	 */
	public void setListOfEventAssignments(
			ListOf<EventAssignment> listOfEventAssignments) {
		this.listOfEventAssignments = listOfEventAssignments;
		setThisAsParentSBMLObject(this.listOfEventAssignments);
		stateChanged();
	}

	/**
	 * 
	 * @param timeUnits
	 */
	public void setTimeUnits(String timeUnits) {
		this.timeUnits = (UnitDefinition) getModel().findNamedSBase(timeUnits);
	}

	/**
	 * 
	 * @param timeUnits
	 */
	public void setTimeUnits(UnitDefinition timeUnits) {
		this.timeUnits = timeUnits;
		stateChanged();
	}

	/**
	 * 
	 * @param trigger
	 */
	public void setTrigger(Trigger trigger) {
		this.trigger = trigger;
		this.trigger.parentSBMLObject = this;
		this.trigger.sbaseAdded();
	}

	/**
	 * 
	 * @param useValuesFromTriggerTime
	 */
	public void setUseValuesFromTriggerTime(boolean useValuesFromTriggerTime) {
		this.useValuesFromTriggerTime = useValuesFromTriggerTime;
	}

}
